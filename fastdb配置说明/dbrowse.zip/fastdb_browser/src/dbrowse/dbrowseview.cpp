/***********************************************************
 * media transfer AG
 * 
 * Package:     FastDB Browser
 * Module:      $RCSfile: dbrowseview.cpp,v $
 * Type:        C++ Source
 * Version:     $Revision: 1.2 $
 * Last changed:
 *   Date: $Date: 2003/11/03 07:40:40 $
 *   By:   $Author: kzerbe $
 * 
 ***********************************************************/
/**
 * @file dbrowseview.h
 *
 * listview window
 */

#include "stdafx.h"
#include "resource.h"

#include "dbrowseView.h"

BOOL CDbrowseView::PreTranslateMessage(MSG* pMsg)
{
  pMsg;
  return FALSE;
}
