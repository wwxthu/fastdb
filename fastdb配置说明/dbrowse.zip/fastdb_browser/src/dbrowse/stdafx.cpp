/***********************************************************
 * media transfer AG
 * 
 * Package:     FastDB Browser
 * Module:      $RCSfile: stdafx.cpp,v $
 * Type:        C++ Source
 * Version:     $Revision: 1.1 $
 * Last changed:
 *   Date: $Date: 2003/10/29 08:47:24 $
 *   By:   $Author: kzerbe $
 * 
 ***********************************************************/
/**
 * @file stdafx.h
 *
 * common header (precompiled)
 */

#include "stdafx.h"

#if (_ATL_VER < 0x0700)
#include <atlimpl.cpp>
#endif //(_ATL_VER < 0x0700)
