//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dbrowse.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PROMPT_QUERY                101
#define IDC_QUERY                       102
#define IDR_MAINFRAME                   128
#define IDR_MDICHILD                    129
#define IDR_HELPVIEW                    130
#define IDD_HELPDIALOG                  201
#define IDR_BINARY1                     211
#define IDR_CONTEXT                     213
#define ID_EDIT                         32773
#define ID_NEWRECORD                    32774
#define ID_COMMIT                       32775
#define ID_ROLLBACK                     32776
#define ID_DELETERECORD                 32777
#define ID_REFRESH                      32779
#define ID_EXPORT                       32780
#define ID_XM_IMPORT                    32781
#define ID_XML_EXPORT                   32782
#define ID_XML_IMPORT                   32783
#define ID_SAVE                         32786
#define ID_NEWELEMENT                   32787
#define ID_DELETE_ELEMENT               32788

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        214
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
