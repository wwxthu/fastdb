
#ifndef __MESSAGES_H__
#define __MESSAGES_H__

#define APP_NAME "FastDB Browser"

#endif
